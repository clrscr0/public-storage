﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;
using POM.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POM.User
{
    public class BasePage : IBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected IWebDriver driver;
        protected int WaitInMS = 40000;
        protected WebDriverWait wait;

        public AdminLoginPage Start(Browser browser, string url)
        {
            log.Debug("Launching page...");
            log.Debug("Browser: " + browser.ToString());
            
            switch (browser)
            {
                case Browser.Chrome:
                    driver = new ChromeDriver();
                    break;
                case Browser.InternetExplorer:
                    driver = new InternetExplorerDriver();
                    break;
                default:
                    Exception browserExc = new Exception("Unsupported browser.");
                    log.Fatal(browserExc);
                    throw browserExc;
            }

            driver.Navigate().GoToUrl(url);
            driver.Manage().Window.Maximize();
            //wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));

            return new AdminLoginPage(driver);
        }

        //@param element is the WebElement that you want to scroll to and then click
        public void ScrollIntoView(IWebElement element)
        {
            var js = (IJavaScriptExecutor) driver;
            js.ExecuteScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'})", element);
        }

        public void End()
        {
            driver.Close();
            driver.Quit();

            log.Info("Test completed.");
        }

    }

    public enum Browser
    {
        Chrome,
        InternetExplorer
    }
}
