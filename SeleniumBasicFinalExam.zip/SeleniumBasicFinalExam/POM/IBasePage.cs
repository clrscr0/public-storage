﻿using log4net;
using POM.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POM
{
    interface IBasePage
    {
        LoginPage Start(Browser browser, string url);
        void End();
    }
}
