﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace POM.User
{
    public class HomePage : AuthBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        By WelcomeMsgBy = By.CssSelector("div.main-wrapper.scrollspy-action > div > div.container > div.row > div > div.row > div > h3");
        By DateInfoBy = By.CssSelector("div.RTL > div > span.h4");

        public HomePage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
        }

        public string GetWelcomeText()
        {
            IWebElement welcomeMsg = wait.Until(elem=>elem.FindElement(WelcomeMsgBy));
            log.Debug("Actual Welcome Message: " + welcomeMsg.GetAttribute("innerText"));
            return welcomeMsg.GetAttribute("innerText");
        }

        public string GetDateInfo()
        {
            IWebElement dateInfo = driver.FindElement(DateInfoBy);
            log.Debug("App Actual Date: " + dateInfo.GetAttribute("innerText"));
            return dateInfo.GetAttribute("innerText");
        }
    }
}