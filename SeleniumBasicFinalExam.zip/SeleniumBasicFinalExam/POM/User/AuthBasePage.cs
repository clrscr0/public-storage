﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POM.User
{

    public class AuthBasePage : BasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private By NavBarListBy = By.CssSelector("ul.main-nav > li > a");

        public AuthBasePage ClickNav(NavButton navBtn)
        {
            //wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(2000));
            //IWebElement navBar = wait.Until(elem => elem.FindElement(NavBarListBy));
            //log.Debug("navBar: " + navBar.GetAttribute("innerText"));
            Actions action = new Actions(driver);
            IWebElement navBtnElem = driver.FindElements(NavBarListBy).Where(elem => elem.Text.Contains(navBtn.ToString().ToUpper())).FirstOrDefault();
            log.Debug("NavBar: " + navBtnElem.Text);
            log.Debug("TagName: " + navBtnElem.TagName);
            log.Debug("Enabled: " + navBtnElem.Enabled);
            action.DoubleClick(navBtnElem).Perform();

            switch (navBtn)
            {
                case NavButton.Tours:
                    return new ToursPage(driver);
                default:
                    Exception navBarExc = new Exception("No such navbar or not yet implemented.");
                    log.Error(navBarExc);
                    throw navBarExc;
            }
        }

        public enum NavButton
        {
            Home,
            Hotels,
            Flights,
            Tours,
            Transfer,
            Visa,
            Blog,
            Offers,
            Company
        }
    }
}
