﻿using log4net;
using OpenQA.Selenium;

namespace POM.User
{
    public class LoginPage : BasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private By emailFieldBy = By.CssSelector("input[name=username");
        private By passwordFieldBy = By.CssSelector("input[name=password]");
        private By loginBtnBy = By.CssSelector("form#loginfrm button.loginbtn");

        public LoginPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public HomePage LoginValid(string email, string password)
        {
            log.Info("User logs in.");
            log.Debug("Email: " + email);
            log.Debug("Password: " + password);
            IWebElement emailField = driver.FindElement(emailFieldBy);
            emailField.SendKeys(email);
            IWebElement passwordField = driver.FindElement(passwordFieldBy);
            passwordField.SendKeys(password);
            IWebElement loginBtn = driver.FindElement(loginBtnBy);
            loginBtn.Click();
            return new HomePage(driver); 
        }
    }
}