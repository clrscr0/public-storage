﻿using log4net;
using OpenQA.Selenium;
using POM.User;

namespace POM.Admin
{
    public class AdminLoginPage : LoginPage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private By emailFieldBy = By.CssSelector("input[name=email");
        private By passwordFieldBy = By.CssSelector("input[name=password]");
        private By loginBtnBy = By.CssSelector("form>button[type=Submit]");


        public AdminLoginPage(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }

        public new AdminHomePage LoginValid(string email, string password)
        {
            log.Info("Admin logs in.");
            log.Debug("Username: " + email);
            log.Debug("Password: " + password);
            IWebElement emailField = driver.FindElement(emailFieldBy);
            emailField.SendKeys(email);
            IWebElement passwordField = driver.FindElement(passwordFieldBy);
            passwordField.SendKeys(password);
            IWebElement loginBtn = driver.FindElement(loginBtnBy);
            loginBtn.Click();
            return new AdminHomePage(driver);
        }
    }
}