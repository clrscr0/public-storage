﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumBasicFinalExam.DTO
{
    public class SupplierDTO
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private string LastName;
        private string FirstName;
        private string Email;
        private string Password;
        private string Country;

        public SupplierDTO(){   }

        public SupplierDTO(string lastName, string firstName, string email, string password, string county)
        {
            this.LastName = lastName;
            this.FirstName = firstName;
            this.Email = DateTime.Now.ToString("ddHHmmss") + email;
            log.Debug("Need to add timestamp to make it unique everytime it's added: " + this.Email);
            this.Password = password;
            this.Country = county;
        }

        public string GetLastName()
        {
            return this.LastName;
        }

        public string GetFirstName()
        {
            return this.FirstName;
        }

        public string GetEmail()
        {
            return this.Email;
        }

        public string GetCountry()
        {
            return this.Country;
        }

        //this is an unsecure implementation
        public string GetPassword()
        {
            return this.Password;
        }
    }
}
